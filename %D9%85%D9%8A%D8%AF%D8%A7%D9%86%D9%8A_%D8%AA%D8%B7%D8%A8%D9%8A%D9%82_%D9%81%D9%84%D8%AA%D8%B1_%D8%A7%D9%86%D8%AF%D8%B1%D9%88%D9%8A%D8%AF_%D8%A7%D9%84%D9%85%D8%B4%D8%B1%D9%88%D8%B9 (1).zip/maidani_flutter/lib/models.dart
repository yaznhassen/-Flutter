class Evidence {
  Evidence(this.status);
  final String status;
  String? path;
  String ocrText = '';
  String? ocrCode;
  String? ocrName;
  String? ocrStatus;
  String ignoreReason = '';

  factory Evidence.fromJson(String status, Map<String, dynamic> json) {
    final e = Evidence(status);
    e.path = json['path'] as String?;
    e.ocrText = (json['ocrText'] as String?) ?? '';
    e.ocrCode = json['ocrCode'] as String?;
    e.ocrName = json['ocrName'] as String?;
    e.ocrStatus = json['ocrStatus'] as String?;
    e.ignoreReason = (json['ignoreReason'] as String?) ?? '';
    return e;
  }

  Map<String, dynamic> toJson() => {
        'path': path,
        'ocrText': ocrText,
        'ocrCode': ocrCode,
        'ocrName': ocrName,
        'ocrStatus': ocrStatus,
        'ignoreReason': ignoreReason,
      };
}

class Sample {
  Sample({required this.id, required this.date});
  final String id;
  String date;
  String name = '';
  String code = '';
  String area = 'عدن';
  String address = '';
  String type = 'S';
  String collector = 'يزن حسن عبدالله علي';
  String reportTitle = '';
  String notes = '';
  int? itemCount;
  bool zeroConfirmed = false;
  String? signaturePath;
  final Map<String, Evidence> evidence = {
    for (final status in statuses) status: Evidence(status)
  };

  static const statuses = ['WORKING', 'CLOSED', 'TRANSFERRED'];
  static const statusLabels = {
    'WORKING': 'صورة الفتح',
    'CLOSED': 'صورة الإغلاق',
    'TRANSFERRED': 'صورة الترحيل',
  };

  factory Sample.fromJson(Map<String, dynamic> json) {
    final s = Sample(
      id: json['id'].toString(),
      date: (json['date'] as String?) ?? dayIso(DateTime.now()),
    );
    s.name = (json['name'] as String?) ?? '';
    s.code = (json['code'] as String?) ?? '';
    s.area = (json['area'] as String?) ?? 'عدن';
    s.address = (json['address'] as String?) ?? '';
    s.type = (json['type'] as String?) ?? 'S';
    s.collector = (json['collector'] as String?) ?? '';
    s.reportTitle = (json['reportTitle'] as String?) ?? '';
    s.notes = (json['notes'] as String?) ?? '';
    s.itemCount = (json['itemCount'] as num?)?.toInt();
    s.zeroConfirmed = json['zeroConfirmed'] == true;
    s.signaturePath = json['signaturePath'] as String?;
    final raw = (json['evidence'] as Map?) ?? {};
    for (final status in statuses) {
      final value = raw[status];
      if (value is Map) {
        s.evidence[status] = Evidence.fromJson(status, Map<String, dynamic>.from(value));
      }
    }
    return s;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date,
        'name': name,
        'code': code,
        'area': area,
        'address': address,
        'type': type,
        'collector': collector,
        'reportTitle': reportTitle,
        'notes': notes,
        'itemCount': itemCount,
        'zeroConfirmed': zeroConfirmed,
        'signaturePath': signaturePath,
        'evidence': evidence.map((k, v) => MapEntry(k, v.toJson())),
      };

  List<String> validationErrors() {
    final errors = <String>[];
    if (name.trim().isEmpty) errors.add('اسم المحل غير موجود');
    if (!RegExp(r'^\d{4,8}$').hasMatch(code)) errors.add('كود المحل يجب أن يكون 4–8 أرقام');
    if (date.isEmpty) errors.add('تاريخ العمل غير موجود');
    if (area.trim().isEmpty) errors.add('المدينة / المنطقة غير موجودة');
    if (itemCount == null || itemCount! < 0 || itemCount! > 100000) {
      errors.add('عدد الأصناف غير مدخل أو غير صالح');
    } else if (itemCount == 0 && !zeroConfirmed) {
      errors.add('عدد الأصناف صفر: يلزم تأكيده');
    }
    if (signaturePath == null) errors.add('التوقيع غير موجود');
    for (final status in statuses) {
      final e = evidence[status]!;
      if (e.path == null) {
        errors.add('${statusLabels[status]} غير مرفقة');
        continue;
      }
      if (e.ignoreReason.trim().isNotEmpty) continue;
      if (e.ocrCode != null && code.isNotEmpty && e.ocrCode != code) {
        errors.add('اختلاف الكود في ${statusLabels[status]} (${e.ocrCode})');
      }
      if (e.ocrStatus != null && e.ocrStatus != status) {
        errors.add('حالة ${statusLabels[status]} مقروءة ${e.ocrStatus}');
      }
    }
    return errors;
  }
}

String dayIso(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

const arabicMonths = [
  '', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو',
  'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

String monthTitle(String isoDate) {
  final date = DateTime.tryParse(isoDate) ?? DateTime.now();
  return '${arabicMonths[date.month]} ${date.year}م';
}

String slashDate(String date) => date.replaceAll('-', '/');
