import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:screenshot/screenshot.dart';
import 'models.dart';
import 'ocr_service.dart';
import 'ocr_parser.dart';
import 'repository.dart';
import 'report_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaidaniApp());
}

class MaidaniApp extends StatelessWidget {
  const MaidaniApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ميداني | تقارير العينات',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: kGreen),
          scaffoldBackgroundColor: const Color(0xfff0f3ef),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(backgroundColor: kGreen, foregroundColor: Colors.white),
        ),
        home: const Directionality(textDirection: TextDirection.rtl, child: HomeScreen()),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final repo = SampleRepository();
  final samples = <Sample>[];
  bool loading = true;
  String? loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await repo.init();
      final loaded = await repo.load();
      if (!mounted) return;
      setState(() { samples.addAll(loaded); loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { loadError = '$e'; loading = false; });
    }
  }

  Future<void> _save() async {
    try {
      await repo.persist(samples);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ البيانات: $e')));
    }
  }

  Future<void> _edit(Sample sample) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => Directionality(textDirection: TextDirection.rtl, child: EditorScreen(sample: sample, repo: repo, onChanged: _save)),
    ));
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final now = DateTime.now();
    final sample = Sample(id: now.microsecondsSinceEpoch.toString(), date: dayIso(now));
    setState(() => samples.insert(0, sample));
    await _save();
    if (!mounted) return;
    await _edit(sample);
  }

  Future<void> _delete(Sample sample) async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('حذف العينة؟'),
      content: Text('سيُحذف سجل ${sample.name.isEmpty ? sample.code : sample.name} من قائمة التطبيق. لن تُحذف الملفات الأصلية من الهاتف.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف'))],
    ));
    if (yes != true) return;
    setState(() => samples.remove(sample));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ميداني | تقارير الإنجاز'), centerTitle: true),
      floatingActionButton: loading || loadError != null ? null : FloatingActionButton.extended(
        onPressed: _add, icon: const Icon(Icons.add), label: const Text('إضافة عينة'),
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : loadError != null
          ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('فشل فتح قاعدة البيانات. لم يتم مسح بياناتك.\n$loadError', textAlign: TextAlign.center)))
          : ListView(
              padding: const EdgeInsets.fromLTRB(14, 20, 14, 110),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Row(children: [
                    const Icon(Icons.assignment_turned_in_outlined, color: kGreen, size: 35),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('تقرير الإنجاز اليومي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      Text('عينات اليوم: ${samples.where((s) => s.date == dayIso(DateTime.now())).length}   |   العينات المكتملة: ${samples.where((s) => s.validationErrors().isEmpty).length}', style: const TextStyle(color: Colors.black54)),
                    ])),
                  ]),
                ),
                const SizedBox(height: 16),
                if (samples.isEmpty) const Padding(padding: EdgeInsets.all(35), child: Center(child: Text('ابدأ بإضافة محل ثم صور الفتح والإغلاق والترحيل.'))),
                for (final s in samples) Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  child: ListTile(
                    onTap: () => _edit(s),
                    title: Text(s.name.trim().isEmpty ? 'عينة جديدة' : s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('الكود: ${s.code.isEmpty ? '—' : s.code}  •  ${s.date}\nالأصناف: ${s.itemCount ?? 'لم يُدخل'}'),
                    isThreeLine: true,
                    leading: Icon(s.validationErrors().isEmpty ? Icons.verified : Icons.pending_actions,
                      color: s.validationErrors().isEmpty ? kGreen : Colors.orange.shade800),
                    trailing: PopupMenuButton<String>(onSelected: (value) { if (value == 'delete') _delete(s); },
                      itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف العينة'))]),
                  ),
                ),
                const SizedBox(height: 10),
                const Text('البيانات والصور محفوظة محليًا على هذا الجهاز. لا تحذف التطبيق قبل أخذ نسخة احتياطية خارجية.', style: TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
    );
  }
}

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.sample, required this.repo, required this.onChanged});
  final Sample sample;
  final SampleRepository repo;
  final Future<void> Function() onChanged;
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final TextEditingController nameCtrl;
  late final TextEditingController codeCtrl;
  late final TextEditingController addressCtrl;
  late final TextEditingController areaCtrl;
  late final TextEditingController titleCtrl;
  late final TextEditingController collectorCtrl;
  late final TextEditingController notesCtrl;
  late final TextEditingController countCtrl;
  final picker = ImagePicker();
  final ocr = OcrService();
  String? readingStatus;
  bool savingSignature = false;
  Sample get s => widget.sample;

  @override
  void initState() {
    super.initState();
    nameCtrl = TextEditingController(text: s.name);
    codeCtrl = TextEditingController(text: s.code);
    addressCtrl = TextEditingController(text: s.address);
    areaCtrl = TextEditingController(text: s.area);
    titleCtrl = TextEditingController(text: s.reportTitle);
    collectorCtrl = TextEditingController(text: s.collector);
    notesCtrl = TextEditingController(text: s.notes);
    countCtrl = TextEditingController(text: s.itemCount?.toString() ?? '');
  }

  @override
  void dispose() {
    for (final ctrl in [nameCtrl, codeCtrl, addressCtrl, areaCtrl, titleCtrl, collectorCtrl, notesCtrl, countCtrl]) {
      ctrl.dispose();
    }
    super.dispose();
  }

  void _editField(void Function() action) {
    setState(() { action(); s.signaturePath = null; });
    widget.onChanged();
  }

  Future<void> _chooseDate() async {
    final initial = DateTime.tryParse(s.date) ?? DateTime.now();
    final d = await showDatePicker(context: context, initialDate: initial,
      firstDate: DateTime(2020), lastDate: DateTime(2035));
    if (d != null) _editField(() => s.date = dayIso(d));
  }

  Future<void> _pickPhoto(String status, ImageSource source) async {
    try {
      final result = await picker.pickImage(source: source, imageQuality: 100);
      if (result == null) return;
      final path = await widget.repo.copyImage(File(result.path), s.id, status);
      if (!mounted) return;
      _editField(() {
        final e = s.evidence[status]!;
        e.path = path;
        e.ocrText = '';
        e.ocrCode = null;
        e.ocrName = null;
        e.ocrStatus = null;
        e.ignoreReason = '';
      });
      await _readPhoto(status);
    } catch (e) {
      _showError('تعذر فتح الصورة: $e');
    }
  }

  Future<void> _readPhoto(String status) async {
    final evidence = s.evidence[status]!;
    if (evidence.path == null) return;
    setState(() => readingStatus = status);
    try {
      final result = await ocr.read(evidence.path!);
      if (!mounted) return;
      StoreCandidate? picked;
      final matches = result.parsed.candidates.where((c) => c.code == s.code).toList();
      if (matches.isNotEmpty) {
        picked = matches.first;
      } else if (result.parsed.candidates.length > 1) {
        picked = await showDialog<StoreCandidate>(context: context, builder: (ctx) => SimpleDialog(
          title: const Text('وجدت أكثر من محل في الصورة. اختر محل هذه العينة:'),
          children: [for (final candidate in result.parsed.candidates)
            SimpleDialogOption(onPressed: () => Navigator.pop(ctx, candidate),
              child: Text('${candidate.code} — ${candidate.name}')),
            SimpleDialogOption(onPressed: () => Navigator.pop(ctx), child: const Text('لا شيء مما سبق؛ سأكتب يدويًا')),
          ],
        ));
        if (!mounted) return;
      } else if (result.parsed.candidates.length == 1) {
        picked = result.parsed.candidates.first;
      }
      final selectedCode = picked?.code ?? (result.parsed.candidates.length > 1 ? null : result.parsed.code);
      final selectedName = picked?.name ?? (result.parsed.candidates.length > 1 ? null : result.parsed.name);
      _editField(() {
        evidence.ocrText = result.text;
        evidence.ocrCode = selectedCode;
        evidence.ocrName = selectedName;
        evidence.ocrStatus = result.parsed.status;
        evidence.ignoreReason = '';
        // Only fill empty fields: never silently replace a reviewed value.
        if (s.code.trim().isEmpty && selectedCode != null) {
          s.code = selectedCode;
          codeCtrl.text = s.code;
        }
        if (s.name.trim().isEmpty && selectedName != null) {
          s.name = selectedName;
          nameCtrl.text = s.name;
        }
      });
      if (selectedCode == null || selectedName == null) {
        _showMessage('تمت القراءة، لكن بعض الحقول لم تُستخرج. راجع النص أسفل الصورة وأكمل البيانات يدويًا.');
      } else {
        _showMessage('تمت قراءة اسم المحل والكود؛ راجعهما قبل اعتماد التقرير.');
      }
    } catch (e) {
      _showError('فشلت قراءة النص: $e\nتأكد من وجود ملفات اللغة في المشروع، أو أدخل البيانات يدويًا.');
    } finally {
      if (mounted) setState(() => readingStatus = null);
    }
  }

  Future<void> _ignoreReading(String status) async {
    final controller = TextEditingController(text: s.evidence[status]!.ignoreReason);
    final reason = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('استبعاد نتيجة قراءة غير صحيحة'),
      content: TextField(controller: controller, maxLines: 3,
        decoration: const InputDecoration(labelText: 'سبب الاستبعاد (إلزامي)', hintText: 'مثال: محرك القراءة خلط بين رقم التاريخ والكود')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('حفظ السبب'))],
    ));
    controller.dispose();
    if (reason == null || reason.isEmpty) return;
    _editField(() => s.evidence[status]!.ignoreReason = reason);
  }

  Future<void> _sign() async {
    final path = await Navigator.of(context).push<String>(MaterialPageRoute(
      builder: (_) => Directionality(textDirection: TextDirection.rtl,
        child: SignatureScreen(repo: widget.repo, sampleId: s.id)),
    ));
    if (path == null || !mounted) return;
    setState(() => s.signaturePath = path);
    widget.onChanged();
  }

  void _showError(String msg) => _showMessage(msg);
  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 5)));
  }

  void _preview() => Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => Directionality(textDirection: TextDirection.rtl, child: PreviewScreen(sample: s)),
  ));

  Widget _field(String label, TextEditingController controller, void Function(String) update,
      {TextInputType? inputType, int maxLines = 1}) => TextField(
    controller: controller, maxLines: maxLines, keyboardType: inputType,
    onChanged: (v) => _editField(() => update(v)),
    decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true),
  );

  Widget _stage(String status) {
    final e = s.evidence[status]!;
    final path = e.path;
    final busy = readingStatus == status;
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(Sample.statusLabels[status]!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 8),
        Container(height: 150, decoration: BoxDecoration(color: const Color(0xfff2f3ee), borderRadius: BorderRadius.circular(9)),
          child: path != null && File(path).existsSync()
            ? Image.file(File(path), fit: BoxFit.contain)
            : const Center(child: Text('لم ترفق الصورة')),
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 5, children: [
          OutlinedButton.icon(onPressed: readingStatus != null ? null : () => _pickPhoto(status, ImageSource.camera),
            icon: const Icon(Icons.camera_alt_outlined), label: const Text('التقاط')),
          OutlinedButton.icon(onPressed: readingStatus != null ? null : () => _pickPhoto(status, ImageSource.gallery),
            icon: const Icon(Icons.image_outlined), label: const Text('المعرض')),
          if (path != null) TextButton.icon(onPressed: readingStatus != null ? null : () => _readPhoto(status),
            icon: const Icon(Icons.document_scanner_outlined), label: const Text('إعادة القراءة')),
        ]),
        if (busy) const LinearProgressIndicator(),
        if (e.ocrText.isNotEmpty) ExpansionTile(title: Text('النص المقروء: ${e.ocrCode ?? 'بدون كود'} | ${e.ocrName ?? 'بدون اسم'}', style: const TextStyle(fontSize: 13)), children: [
          SelectableText(e.ocrText),
          if (e.ocrCode != null || e.ocrStatus != null)
            TextButton(onPressed: () => _ignoreReading(status), child: const Text('القراءة خاطئة؟ توثيق سبب الاستبعاد')),
          if (e.ignoreReason.isNotEmpty) Text('سبب الاستبعاد: ${e.ignoreReason}', style: const TextStyle(color: Colors.deepOrange)),
        ]),
      ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    final errors = s.validationErrors();
    return Scaffold(
      appBar: AppBar(title: const Text('بيانات العينة'), actions: [
        IconButton(onPressed: _preview, tooltip: 'معاينة التقرير', icon: const Icon(Icons.picture_as_pdf_outlined)),
      ]),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 15, 14, 35), children: [
        const Text('تُملأ الخانات من الصور عند نجاح القراءة، ويمكن تصحيحها يدويًا. لا يُغيَّر اسم أو كود مكتوب سابقًا دون مراجعتك.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 14),
        _field('اسم البقالة / العينة', nameCtrl, (v) => s.name = v),
        const SizedBox(height: 11),
        _field('كود المحل', codeCtrl, (v) => s.code = normalizeShopCode(v), inputType: TextInputType.number),
        const SizedBox(height: 11),
        _field('عنوان المحل التفصيلي', addressCtrl, (v) => s.address = v),
        const SizedBox(height: 11),
        _field('المدينة / المنطقة', areaCtrl, (v) => s.area = v),
        const SizedBox(height: 11),
        DropdownButtonFormField<String>(
          initialValue: s.type,
          decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'نوع العينة'),
          items: ['S', 'M', 'L'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) { if (v != null) _editField(() => s.type = v); },
        ),
        const SizedBox(height: 11),
        OutlinedButton.icon(onPressed: _chooseDate, icon: const Icon(Icons.calendar_month), label: Text('تاريخ العمل: ${s.date}')),
        const SizedBox(height: 11),
        _field('عدد أصناف هذا المحل (يدوي)', countCtrl, (v) {
          s.itemCount = v.trim().isEmpty ? null : int.tryParse(v);
          s.zeroConfirmed = false;
        }, inputType: TextInputType.number),
        if (s.itemCount == 0) CheckboxListTile(value: s.zeroConfirmed,
          onChanged: (v) => _editField(() => s.zeroConfirmed = v ?? false),
          title: const Text('أؤكد أن عدد الأصناف صفر')),
        const SizedBox(height: 11),
        _field('عنوان التقرير (اختياري)', titleCtrl, (v) => s.reportTitle = v),
        const SizedBox(height: 11),
        _field('جامع البيانات', collectorCtrl, (v) => s.collector = v),
        const SizedBox(height: 11),
        _field('ملاحظات المحل', notesCtrl, (v) => s.notes = v, maxLines: 3),
        const SizedBox(height: 18),
        const Text('صور التوثيق الثلاث', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 9),
        for (final status in Sample.statuses) _stage(status),
        Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(s.signaturePath == null ? 'التوقيع: غير مرفق' : 'التوقيع: محفوظ', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          OutlinedButton.icon(onPressed: _sign, icon: const Icon(Icons.draw_outlined), label: const Text('ارسم توقيع العينة')),
        ]))),
        if (errors.isNotEmpty) Container(
          margin: const EdgeInsets.only(top: 12), padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: const Color(0xfffff2e1), borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('نواقص تمنع اعتماد التقرير:', style: TextStyle(fontWeight: FontWeight.bold)),
            for (final error in errors) Text('• $error'),
          ]),
        ),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: _preview, icon: const Icon(Icons.preview), label: const Text('معاينة التقرير / تصدير PDF')),
      ]),
    );
  }
}

String normalizeShopCode(String text) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  var v = text.trim();
  for (var i = 0; i < 10; i++) {
    v = v.replaceAll(ar[i], '$i').replaceAll(fa[i], '$i');
  }
  return v;
}

class SignatureScreen extends StatefulWidget {
  const SignatureScreen({super.key, required this.repo, required this.sampleId});
  final SampleRepository repo;
  final String sampleId;
  @override
  State<SignatureScreen> createState() => _SignatureScreenState();
}

class _SignatureScreenState extends State<SignatureScreen> {
  final key = GlobalKey();
  final strokes = <List<Offset>>[];
  bool busy = false;

  Future<void> _save() async {
    if (strokes.isEmpty || strokes.every((list) => list.length < 2)) return;
    setState(() => busy = true);
    try {
      final boundary = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 2.5);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      final bytes = data!.buffer.asUint8List();
      final target = File('${widget.repo.root.path}/signature_${widget.sampleId}_${DateTime.now().microsecondsSinceEpoch}.png');
      await target.writeAsBytes(bytes, flush: true);
      if (!mounted) return;
      Navigator.of(context).pop(target.path);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ التوقيع: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('التوقيع اليدوي')),
    body: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
      const Text('ارسم توقيعك بإصبعك. تعديل العينة بعد التوقيع يلغي اعتماد التوقيع ويستلزم إعادة التوقيع.'),
      const SizedBox(height: 20),
      RepaintBoundary(key: key, child: Container(
        color: Colors.white,
        child: SizedBox(height: 220, width: double.infinity, child: GestureDetector(
          onPanStart: (details) => setState(() => strokes.add([details.localPosition])),
          onPanUpdate: (details) => setState(() => strokes.last.add(details.localPosition)),
          child: CustomPaint(painter: _SignaturePainter(strokes), size: const Size(double.infinity, 220)),
        )),
      )),
      Row(children: [
        TextButton(onPressed: () => setState(() => strokes.clear()), child: const Text('مسح التوقيع')),
        const Spacer(),
        FilledButton(onPressed: busy ? null : _save, child: const Text('حفظ التوقيع')),
      ]),
    ])),
  );
}

class _SignaturePainter extends CustomPainter {
  const _SignaturePainter(this.strokes);
  final List<List<Offset>> strokes;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xff202020)..strokeWidth = 3..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    for (final points in strokes) {
      if (points.length < 2) continue;
      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (final point in points.skip(1)) { path.lineTo(point.dx, point.dy); }
      canvas.drawPath(path, paint);
    }
  }
  @override
  bool shouldRepaint(_SignaturePainter oldDelegate) => true;
}

class PreviewScreen extends StatefulWidget {
  const PreviewScreen({super.key, required this.sample});
  final Sample sample;
  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  bool exporting = false;

  Future<Uint8List> _pdf() async {
    final document = pw.Document(compress: true);
    final screenshots = ScreenshotController();
    for (var i = 0; i < 2; i++) {
      final png = await screenshots.captureFromWidget(
        Material(color: Colors.white, child: Directionality(
          textDirection: TextDirection.rtl, child: ReportPage(sample: widget.sample, index: i),
        )),
        context: context,
        delay: const Duration(milliseconds: 350),
        pixelRatio: 2,
      );
      document.addPage(pw.Page(pageFormat: PdfPageFormat.a4.landscape,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pw.MemoryImage(png), fit: pw.BoxFit.fill)));
    }
    return document.save();
  }

  Future<void> _export({required bool share}) async {
    final errors = widget.sample.validationErrors();
    if (errors.isNotEmpty) {
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('لا يمكن اعتماد التقرير'),
        content: SingleChildScrollView(child: Text(errors.join('\n'))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('مراجعة البيانات'))],
      ));
      return;
    }
    setState(() => exporting = true);
    try {
      final bytes = await _pdf();
      if (!mounted) return;
      if (share) {
        await Printing.sharePdf(bytes: bytes, filename: 'maidani_${widget.sample.code}_${widget.sample.date}.pdf');
      } else {
        await Printing.layoutPdf(onLayout: (_) async => bytes, name: 'ميداني ${widget.sample.code}');
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء PDF: $e')));
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final issues = widget.sample.validationErrors();
    return Scaffold(
      appBar: AppBar(title: const Text('معاينة التقرير')),
      body: Column(children: [
        if (issues.isNotEmpty) Container(
          color: const Color(0xffffe9d6), padding: const EdgeInsets.all(12),
          child: Text('التقرير مسودة غير مكتملة: ${issues.join('، ')}', maxLines: 3, overflow: TextOverflow.ellipsis),
        ),
        Expanded(child: ListView(padding: const EdgeInsets.all(9), children: [
          for (var i = 0; i < 2; i++) Card(margin: const EdgeInsets.only(bottom: 14), child: LayoutBuilder(
            builder: (context, constraints) => SizedBox(
              width: constraints.maxWidth,
              height: constraints.maxWidth * 794 / 1123,
              child: FittedBox(fit: BoxFit.contain, child: ReportPage(sample: widget.sample, index: i)),
            ),
          )),
        ])),
        Padding(padding: const EdgeInsets.all(12), child: Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: exporting ? null : () => _export(share: false),
            icon: const Icon(Icons.print), label: const Text('طباعة / حفظ PDF'))),
          const SizedBox(width: 9),
          Expanded(child: FilledButton.icon(onPressed: exporting ? null : () => _export(share: true),
            icon: const Icon(Icons.share), label: const Text('مشاركة PDF'))),
        ])),
        if (exporting) const LinearProgressIndicator(),
      ]),
    );
  }
}
