import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'ocr_parser.dart';

class OcrService {
  Future<({String text, ParsedOcr parsed})> read(String path) async {
    final text = await FlutterTesseractOcr.extractText(
      path,
      language: 'ara+eng',
      args: {'psm': '6', 'preserve_interword_spaces': '1'},
    );
    return (text: text, parsed: parseOcr(text));
  }
}
