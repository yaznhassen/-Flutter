import 'dart:io';
import 'package:flutter/material.dart';
import 'models.dart';

const kGold = Color(0xffbba039);
const kGreen = Color(0xff17664f);

class ReportPage extends StatelessWidget {
  const ReportPage({super.key, required this.sample, required this.index});
  final Sample sample;
  final int index;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1123,
      height: 794,
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(23, 20, 23, 25),
      child: index == 0 ? _firstPage() : _secondPage(),
    );
  }

  Widget _firstPage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 92,
          child: Row(
            textDirection: TextDirection.ltr,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset('assets/branding/hsa_logo.jpg', width: 265, fit: BoxFit.contain),
              const Spacer(),
              const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('مجموعة هائل سعيد أنعم وشركاه', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
                  Text('الإدارة العامة للتسويق - إقليم اليمن', style: TextStyle(fontSize: 17)),
                  Text('قسم الدراسات والبحوث | Retail Audit', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                ],
              ),
            ],
          ),
        ),
        Container(height: 3, color: kGold),
        const SizedBox(height: 40),
        Container(
          alignment: Alignment.center,
          height: 77,
          decoration: BoxDecoration(border: Border.all(color: Colors.black, width: 1.2)),
          foregroundDecoration: const BoxDecoration(border: Border(top: BorderSide(color: kGold, width: 2), bottom: BorderSide(color: kGold, width: 2))),
          child: Text(
            sample.reportTitle.trim().isEmpty
                ? 'تـقــريــــــر الإنجاز اليومي للعينات - ${monthTitle(sample.date)}'
                : sample.reportTitle,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 32, color: Colors.black87, fontWeight: FontWeight.w500),
          ),
        ),
        const SizedBox(height: 37),
        _table(),
        const SizedBox(height: 38),
        _sectionLabel('توثيق النظام - حالة المحل: ترحيل (TRANSFERRED)', color: kGreen),
        Container(
          height: 245,
          padding: const EdgeInsets.all(8),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: kGold, width: 2))),
          child: _image(sample.evidence['TRANSFERRED']?.path),
        ),
        const Spacer(),
        _pageNumber('1 / 2'),
      ],
    );
  }

  Widget _secondPage() {
    return Column(
      children: [
        Container(height: 3, color: kGold),
        const SizedBox(height: 25),
        Row(
          children: [
            Expanded(child: Column(children: [
              _sectionLabel('توثيق النظام - حالة المحل: عامل (WORKING)', color: kGreen),
              Container(height: 350, padding: const EdgeInsets.all(12), decoration: BoxDecoration(border: Border.all(color: Colors.black12)), child: _image(sample.evidence['WORKING']?.path)),
            ])),
            const SizedBox(width: 16),
            Expanded(child: Column(children: [
              _sectionLabel('توثيق النظام - حالة المحل: مغلق سابقًا (CLOSED)', color: Colors.red),
              Container(height: 350, padding: const EdgeInsets.all(12), decoration: BoxDecoration(border: Border.all(color: Colors.black12)), child: _image(sample.evidence['CLOSED']?.path)),
            ])),
          ],
        ),
        const SizedBox(height: 35),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xfffbfaf5),
              border: const Border(top: BorderSide(color: kGold, width: 2), bottom: BorderSide(color: Colors.black87, width: 2)),
            ),
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                _footerCell('إجمالي العينات المنجزة: 1\nعدد أصناف المحل: ${sample.itemCount ?? '—'}', flex: 11),
                _footerCell('اسم جامع البيانات:\n${sample.collector}', flex: 13),
                _footerCell('ملاحظات منفذ البيع (البقالة):\n${sample.notes}', flex: 12),
                Expanded(
                  flex: 14,
                  child: Container(
                    height: double.infinity,
                    decoration: const BoxDecoration(border: Border(right: BorderSide(color: Colors.black12))),
                    child: Column(
                      children: [
                        const Padding(padding: EdgeInsets.only(top: 10), child: Text('التوقيع:', style: TextStyle(fontSize: 18))),
                        Expanded(child: Padding(padding: const EdgeInsets.all(9), child: _image(sample.signaturePath))),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _pageNumber('2 / 2'),
      ],
    );
  }

  Widget _footerCell(String text, {required int flex}) => Expanded(
        flex: flex,
        child: Container(
          height: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          alignment: Alignment.center,
          decoration: const BoxDecoration(border: Border(right: BorderSide(color: Colors.black12))),
          child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 17), maxLines: 8, overflow: TextOverflow.ellipsis),
        ),
      );

  Widget _table() {
    const headers = ['التاريخ', 'اسم المحل', 'رقم الكود', 'نوع العينة', 'المدينة / المنطقة', 'عدد الأصناف'];
    final values = [slashDate(sample.date), sample.name, sample.code, sample.type, sample.address.trim().isEmpty ? sample.area : '${sample.area} — ${sample.address}', '${sample.itemCount ?? '—'}'];
    final widths = [155.0, 275.0, 147.0, 105.0, 250.0, 144.0];
    return Table(
      border: TableBorder.all(color: const Color(0xffddd8c6)),
      columnWidths: {for (var i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
      children: [
        TableRow(
          decoration: const BoxDecoration(color: Color(0xff282827), border: Border(top: BorderSide(color: kGold, width: 2), bottom: BorderSide(color: kGold, width: 2))),
          children: [for (final h in headers) _cell(h, header: true)],
        ),
        TableRow(children: [for (var i = 0; i < values.length; i++) _cell(values[i], code: i == 2)]),
      ],
    );
  }

  Widget _cell(String value, {bool header = false, bool code = false}) => Container(
        height: 52,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Text(value, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
          style: TextStyle(fontSize: header ? 16 : 17, fontWeight: FontWeight.w600, color: header ? Colors.white : (code ? const Color(0xffa7211a) : Colors.black87))),
      );

  Widget _sectionLabel(String title, {required Color color}) => Container(
        height: 37,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: const Color(0xfff6f6f6), border: Border(top: BorderSide(color: color, width: 2), bottom: const BorderSide(color: Colors.black12))),
        child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
      );

  Widget _image(String? path) => path != null && File(path).existsSync()
      ? Image.file(File(path), fit: BoxFit.contain)
      : const Center(child: Text('الصورة غير مرفقة', style: TextStyle(color: Colors.grey)));

  Widget _pageNumber(String value) => Align(
        alignment: Alignment.center,
        child: Text(value, style: const TextStyle(color: Colors.grey, fontSize: 14)),
      );
}
