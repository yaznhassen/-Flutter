class StoreCandidate {
  const StoreCandidate(this.code, this.name);
  final String code;
  final String name;
}

class ParsedOcr {
  const ParsedOcr({this.code, this.name, this.status, this.candidates = const []});
  final String? code;
  final String? name;
  final String? status;
  final List<StoreCandidate> candidates;
}

String normalizeDigits(String text) {
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  var output = text;
  for (var i = 0; i < 10; i++) {
    output = output.replaceAll(arabic[i], '$i').replaceAll(persian[i], '$i');
  }
  return output.replaceAll('ـ', '');
}

ParsedOcr parseOcr(String input) {
  final text = normalizeDigits(input);
  final lines = text
      .split(RegExp(r'[\n\r]+'))
      .map((s) => s.trim().replaceAll(RegExp(r'\s+'), ' '))
      .where((s) => s.isNotEmpty)
      .toList();
  final whole = text.toUpperCase();
  String? state;
  for (final v in ['TRANSFERRED', 'CLOSED', 'WORKING']) {
    if (whole.contains(v)) {
      state = v;
      break;
    }
  }

  final codeLabel = RegExp(r'(?:كود\s*(?:المحل|العينة)?|رقم\s*(?:الكود|المحل)|STORE\s*CODE|SHOP\s*CODE|CODE|ID)\s*[:：#\-]?\s*(.*)', caseSensitive: false);
  final codePattern = RegExp(r'(?:^|[^\d])((?:\d[ \-]*){4,8})(?=[^\d]|$)');
  String? bestCode;
  var bestScore = -100;
  for (final line in lines) {
    final upper = line.toUpperCase();
    // Date rows are not shop codes.
    if (RegExp(r'\d{1,4}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{1,4}').hasMatch(line)) continue;
    final labeled = codeLabel.firstMatch(line);
    final source = labeled != null ? labeled.group(1)! : line;
    for (final match in codePattern.allMatches(source)) {
      final digits = match.group(1)!.replaceAll(RegExp(r'[^0-9]'), '');
      if (digits.length < 4 || digits.length > 8) continue;
      if (digits.startsWith('20') && digits.length == 4) continue;
      var score = labeled != null ? 15 : 0;
      if (line.trimLeft().startsWith(digits)) score += 4;
      if (RegExp(r'\b(?:WORKING|CLOSED|TRANSFERRED)\b', caseSensitive: false).hasMatch(line)) score -= 4;
      if (digits.length == 5) score += 2;
      if (score > bestScore) {
        bestScore = score;
        bestCode = digits;
      }
    }
  }

  final nameLabel = RegExp(
    r'(?:اسم\s*(?:المحل|البقالة|العينة)|اسم\s*منفذ\s*البيع|STORE\s*NAME|SHOP\s*NAME)\s*[:：\-]?\s*(.*)',
    caseSensitive: false,
  );
  bool isNoise(String raw) {
    final l = raw.trim();
    if (l.isEmpty || l.length < 3) return true;
    if (RegExp(r'^(?:\d|[-./])+$').hasMatch(l)) return true;
    if (RegExp(r'(?:WORKING|CLOSED|TRANSFERRED|مغلق|ترحيل|عامل|كود\s*المحل|رقم\s*الكود)', caseSensitive: false).hasMatch(l)) return true;
    if (RegExp(r'\d{1,4}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{1,4}').hasMatch(l)) return true;
    if (RegExp(r'(?:عدن|كريتر|المنصورة|البريقة|المنطقة|المدينة)\s*[:：\-]').hasMatch(l)) return true;
    return !RegExp(r'[A-Za-z\u0600-\u06FF]').hasMatch(l);
  }

  String? name;
  for (var i = 0; i < lines.length; i++) {
    final m = nameLabel.firstMatch(lines[i]);
    if (m == null) continue;
    var candidate = (m.group(1) ?? '').trim();
    if (candidate.isEmpty && i + 1 < lines.length) candidate = lines[i + 1];
    if (!isNoise(candidate)) {
      name = candidate;
      break;
    }
  }
  if (name == null && bestCode != null) {
    for (var i = 0; i < lines.length; i++) {
      final normalized = lines[i].replaceAll(RegExp(r'[\s\-]'), '');
      if (!normalized.contains(bestCode)) continue;
      final withoutCode = lines[i].replaceFirst(RegExp(bestCode!.split('').join(r'[\s\-]*')), '').trim();
      if (!isNoise(withoutCode)) {
        name = withoutCode;
        break;
      }
      // Some screenshots put the name between code and WORKING/CLOSED.
      if (i + 1 < lines.length && !isNoise(lines[i + 1])) {
        name = lines[i + 1];
        break;
      }
    }
  }
  // Screenshots may contain several stores. Return all reliably paired rows.
  // The UI must ask the user to select the correct store instead of guessing.
  final candidates = <StoreCandidate>[];
  for (final line in lines) {
    if (RegExp(r'\d{1,4}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{1,4}').hasMatch(line)) continue;
    final match = codePattern.firstMatch(line);
    if (match == null) continue;
    final digits = match.group(1)!.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length < 4 || digits.length > 8) continue;
    final rest = line.substring(match.end).trim().replaceAll(RegExp(r'^[\s:：\-]+'), '');
    if (isNoise(rest)) continue;
    if (!candidates.any((c) => c.code == digits && c.name == rest)) {
      candidates.add(StoreCandidate(digits, rest));
    }
  }
  return ParsedOcr(code: bestCode, name: name, status: state, candidates: candidates);
}
