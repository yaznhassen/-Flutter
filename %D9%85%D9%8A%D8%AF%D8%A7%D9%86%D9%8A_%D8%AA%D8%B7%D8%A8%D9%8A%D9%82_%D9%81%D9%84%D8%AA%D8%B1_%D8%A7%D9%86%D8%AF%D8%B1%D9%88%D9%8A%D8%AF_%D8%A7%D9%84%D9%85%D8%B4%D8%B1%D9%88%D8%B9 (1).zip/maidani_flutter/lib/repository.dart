import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'models.dart';

class SampleRepository {
  late final Directory root;
  late final File _jsonFile;
  Future<void> _pending = Future.value();

  Future<void> init() async {
    final folder = await getApplicationDocumentsDirectory();
    root = Directory('${folder.path}/maidani');
    await root.create(recursive: true);
    _jsonFile = File('${root.path}/samples.json');
  }

  Future<List<Sample>> load() async {
    if (!await _jsonFile.exists()) return [];
    try {
      final data = jsonDecode(await _jsonFile.readAsString()) as List;
      return data.map((e) => Sample.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      // Never overwrite a corrupt or unexpected file silently.
      rethrow;
    }
  }

  Future<void> persist(List<Sample> samples) {
    final encoded = jsonEncode(samples.map((e) => e.toJson()).toList());
    _pending = _pending.catchError((_) {}).then((_) async {
      final tmp = File('${_jsonFile.path}.tmp');
      await tmp.writeAsString(encoded, flush: true);
      // Atomic replacement on Android (same filesystem). Keep a recovery copy.
      if (await _jsonFile.exists()) {
        await _jsonFile.copy('${_jsonFile.path}.bak');
      }
      await tmp.rename(_jsonFile.path);
    });
    return _pending;
  }

  Future<String> copyImage(File source, String sampleId, String stage) async {
    final extension = source.path.split('.').last.toLowerCase();
    final safeExt = ['png', 'jpeg', 'jpg', 'webp'].contains(extension) ? extension : 'jpg';
    final target = File('${root.path}/${sampleId}_${stage}_${DateTime.now().microsecondsSinceEpoch}.$safeExt');
    await source.copy(target.path);
    return target.path;
  }
}
