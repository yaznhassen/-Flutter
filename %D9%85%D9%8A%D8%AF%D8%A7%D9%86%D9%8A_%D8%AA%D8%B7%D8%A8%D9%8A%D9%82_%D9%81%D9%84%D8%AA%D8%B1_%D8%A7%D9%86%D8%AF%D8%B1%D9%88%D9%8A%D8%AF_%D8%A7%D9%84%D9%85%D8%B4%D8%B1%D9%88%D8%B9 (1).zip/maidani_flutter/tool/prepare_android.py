"""Run after flutter create --platforms=android to set the Android label and minSdk."""
from pathlib import Path

for name in ('android/app/build.gradle.kts','android/app/build.gradle'):
    file = Path(name)
    if not file.exists():
        continue
    text = file.read_text(encoding='utf-8')
    text = text.replace('minSdk = flutter.minSdkVersion', 'minSdk = 24')
    text = text.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 24')
    file.write_text(text, encoding='utf-8')

manifest = Path('android/app/src/main/AndroidManifest.xml')
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    text = text.replace('android:label="maidani"', 'android:label="ميداني"')
    manifest.write_text(text, encoding='utf-8')
print('Android manifest/minSdk prepared.')
