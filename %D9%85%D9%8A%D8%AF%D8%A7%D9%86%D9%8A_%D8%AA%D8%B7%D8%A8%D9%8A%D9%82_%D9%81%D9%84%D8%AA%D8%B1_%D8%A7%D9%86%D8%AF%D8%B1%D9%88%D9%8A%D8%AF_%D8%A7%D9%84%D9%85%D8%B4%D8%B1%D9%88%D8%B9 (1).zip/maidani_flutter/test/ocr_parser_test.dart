import 'package:flutter_test/flutter_test.dart';
import 'package:maidani/ocr_parser.dart';
import 'package:maidani/models.dart';

void main() {
  test('English row extracts leading zero in code and store name', () {
    final r = parseOcr('02190 Tamwinat Rukn Alkhatib\nWORKING 12/11/2026');
    expect(r.code, '02190');
    expect(r.name, 'Tamwinat Rukn Alkhatib');
    expect(r.status, 'WORKING');
  });
  test('Space inside code is accepted', () {
    final r = parseOcr('02 190 Tamwinat Rukn Alkhatib\nTRANSFERRED 12/11/2026');
    expect(r.code, '02190');
    expect(r.name, 'Tamwinat Rukn Alkhatib');
  });
  test('Arabic labelled name is not replaced with code label', () {
    final r = parseOcr('اسم البقالة: بقالة الخير\nكود المحل: ٠٢١٩٠');
    expect(r.name, 'بقالة الخير');
    expect(r.code, '02190');
  });
  test('Two shops in one screenshot are offered as choices', () {
    final r = parseOcr('00322 Bkala Ahmadi\n02130 Tamwenat abo yaasr\nTRANSFERRED 17/10/2026');
    expect(r.candidates.length, 2);
    expect(r.candidates.last.code, '02130');
  });
  test('Different photo code blocks report', () {
    final s = Sample(id: 't', date: '2026-11-12')
      ..name = 'محل الخير'
      ..code = '02190'
      ..itemCount = 10
      ..signaturePath = '/sig.png';
    for (final stage in Sample.statuses) {
      s.evidence[stage]!.path = '/photo.png';
      s.evidence[stage]!.ocrCode = '02190';
    }
    expect(s.validationErrors(), isEmpty);
    s.evidence['TRANSFERRED']!.ocrCode = '02555';
    expect(s.validationErrors().join(' '), contains('اختلاف الكود'));
  });
}
